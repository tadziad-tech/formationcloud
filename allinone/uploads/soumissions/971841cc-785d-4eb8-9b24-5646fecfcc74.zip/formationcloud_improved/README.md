# FormationCloud - Plateforme de Gestion des Stagiaires

## Description
FormationCloud est une plateforme cloud web pour la gestion des stagiaires, des formations et des sessions de formation. Cette application permet de gérer les utilisateurs (administrateurs, formateurs et stagiaires), les formations, les sessions de formation, les tâches assignées aux stagiaires et les évaluations.

## Technologies
- Java 17
- Spring Boot 3.x
- Spring Data JPA
- Spring Validation
- MySQL
- Flyway (migrations de base de données)
- Lombok
- Docker

## Structure de la base de données
L'application utilise les entités suivantes :
- **Utilisateur** : Représente un utilisateur du système (administrateur, formateur ou stagiaire)
- **Formation** : Représente une formation disponible
- **SessionFormation** : Représente une session spécifique d'une formation
- **Tache** : Représente une tâche assignée à un stagiaire dans le cadre d'une formation
- **Evaluation** : Représente l'évaluation d'un stagiaire pour une formation
- **Participation** : Représente la participation d'un stagiaire à une session de formation

## Configuration
L'application peut être configurée via les fichiers `application.properties` et `application-cloud.properties` :
- `application.properties` : Configuration par défaut pour le développement local
- `application-cloud.properties` : Configuration pour le déploiement cloud avec des variables d'environnement

### Variables d'environnement
- `DATABASE_URL` : URL de connexion à la base de données
- `DATABASE_USERNAME` : Nom d'utilisateur de la base de données
- `DATABASE_PASSWORD` : Mot de passe de la base de données
- `PORT` : Port sur lequel l'application s'exécute (par défaut 8080)

## Migrations de base de données
L'application utilise Flyway pour gérer les migrations de base de données :
- `V1__Create_Tables.sql` : Création des tables de la base de données
- `V2__Insert_Sample_Data.sql` : Insertion de données d'exemple

## API Endpoints
### Utilisateurs
- `GET /api/utilisateurs` : Récupérer tous les utilisateurs
- `GET /api/utilisateurs/{id}` : Récupérer un utilisateur par ID
- `GET /api/utilisateurs/email/{email}` : Récupérer un utilisateur par email
- `POST /api/utilisateurs` : Créer un nouvel utilisateur
- `PUT /api/utilisateurs/{id}` : Mettre à jour un utilisateur
- `DELETE /api/utilisateurs/{id}` : Supprimer un utilisateur

### Formations
- `GET /api/formations` : Récupérer toutes les formations
- `GET /api/formations/{id}` : Récupérer une formation par ID
- `POST /api/formations` : Créer une nouvelle formation
- `PUT /api/formations/{id}` : Mettre à jour une formation
- `DELETE /api/formations/{id}` : Supprimer une formation

### Health Check
- `GET /api/health` : Vérifier l'état de l'application

## Déploiement
### Prérequis
- Java 17
- Maven 3.6+
- MySQL 8.0+
- Docker (optionnel, pour containerisation)

### Instructions de déploiement local
1. Importer le projet dans IntelliJ/Eclipse (Import as Maven project)
2. Vérifier application.properties (src/main/resources)
3. Lancer MySQL et créer la BDD 'gestion_formation' si elle n'existe pas
4. Exécuter `mvn spring-boot:run`

### Instructions de déploiement cloud
1. Définir les variables d'environnement requises
2. Exécuter l'application avec le profil "cloud" : `java -jar -Dspring.profiles.active=cloud formationcloud-0.0.1-SNAPSHOT.jar`

### Containerisation avec Docker
1. Compiler le projet : `mvn clean package`
2. Construire l'image Docker : `docker build -t formationcloud .`
3. Exécuter le conteneur : `docker run -p 8080:8080 formationcloud`

## Améliorations implémentées
1. Validation des données avec Bean Validation
2. Gestion centralisée des exceptions
3. Journalisation (logging) avec Logback
4. Support des migrations de base de données avec Flyway
5. Configuration cloud-ready avec variables d'environnement
6. Health check endpoint
7. Dockerfile pour containerisation
8. Structure de packages améliorée

## Prochaines étapes (sécurité et cloud)
Les fonctionnalités de sécurité et de déploiement cloud avancé seront implémentées dans les prochaines versions :
- Intégration de Spring Security
- Mécanismes d'authentification et d'autorisation
- Chiffrement des mots de passe
- Support des tokens JWT pour l'authentification stateless