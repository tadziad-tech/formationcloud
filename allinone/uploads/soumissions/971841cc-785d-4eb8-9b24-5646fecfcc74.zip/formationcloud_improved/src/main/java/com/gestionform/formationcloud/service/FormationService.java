package com.gestionform.formationcloud.service;

import com.gestionform.formationcloud.model.Formation;
import com.gestionform.formationcloud.repository.FormationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FormationService {

    private static final Logger logger = LoggerFactory.getLogger(FormationService.class);
    
    private final FormationRepository repo;

    public FormationService(FormationRepository repo) {
        this.repo = repo;
    }

    public List<Formation> findAll() {
        logger.info("Récupération de toutes les formations");
        return repo.findAll();
    }
    
    public Optional<Formation> findById(Long id) {
        logger.info("Recherche de la formation avec l'id : {}", id);
        return repo.findById(id);
    }
    
    public Formation save(Formation f) {
        logger.info("Enregistrement de la formation : {}", f.getTitre());
        return repo.save(f);
    }
    
    public void delete(Long id) {
        logger.info("Suppression de la formation avec l'id : {}", id);
        repo.deleteById(id);
    }
}