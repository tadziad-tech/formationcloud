package com.gestionform.formationcloud.repository;

import com.gestionform.formationcloud.model.Tache;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TacheRepository extends JpaRepository<Tache, Long> {
}
