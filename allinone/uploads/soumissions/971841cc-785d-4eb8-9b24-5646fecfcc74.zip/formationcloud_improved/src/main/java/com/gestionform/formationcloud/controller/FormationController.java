package com.gestionform.formationcloud.controller;

import com.gestionform.formationcloud.exception.ResourceNotFoundException;
import com.gestionform.formationcloud.model.Formation;
import com.gestionform.formationcloud.service.FormationService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/formations")
@CrossOrigin(origins = "*")
public class FormationController {
    
    private static final Logger logger = LoggerFactory.getLogger(FormationController.class);
    
    private final FormationService service;
    
    public FormationController(FormationService service) {
        this.service = service;
    }
    
    @GetMapping
    public List<Formation> all() {
        logger.info("Récupération de toutes les formations");
        return service.findAll();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Formation> get(@PathVariable Long id) {
        logger.info("Récupération de la formation avec l'id : {}", id);
        Formation formation = service.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Formation non trouvée avec l'id : " + id));
        return ResponseEntity.ok(formation);
    }
    
    @PostMapping
    public Formation create(@Valid @RequestBody Formation formation) {
        logger.info("Création d'une nouvelle formation : {}", formation.getTitre());
        return service.save(formation);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Formation> update(@PathVariable Long id, @Valid @RequestBody Formation formationDetails) {
        logger.info("Mise à jour de la formation avec l'id : {}", id);
        Formation formation = service.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Formation non trouvée avec l'id : " + id));
        
        formation.setTitre(formationDetails.getTitre());
        formation.setDescription(formationDetails.getDescription());
        formation.setDateDebut(formationDetails.getDateDebut());
        formation.setDateFin(formationDetails.getDateFin());
        formation.setLieu(formationDetails.getLieu());
        formation.setFormateur(formationDetails.getFormateur());
        
        Formation updatedFormation = service.save(formation);
        return ResponseEntity.ok(updatedFormation);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        logger.info("Suppression de la formation avec l'id : {}", id);
        Formation formation = service.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Formation non trouvée avec l'id : " + id));
        service.delete(id);
        return ResponseEntity.ok().build();
    }
}