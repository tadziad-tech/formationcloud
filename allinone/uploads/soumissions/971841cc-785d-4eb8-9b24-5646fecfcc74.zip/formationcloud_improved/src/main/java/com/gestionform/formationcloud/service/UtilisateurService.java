package com.gestionform.formationcloud.service;

import com.gestionform.formationcloud.model.Utilisateur;
import com.gestionform.formationcloud.repository.UtilisateurRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UtilisateurService {
    
    private static final Logger logger = LoggerFactory.getLogger(UtilisateurService.class);
    
    private final UtilisateurRepository repo;
    
    public UtilisateurService(UtilisateurRepository repo) {
        this.repo = repo;
    }
    
    public List<Utilisateur> findAll() {
        logger.info("Récupération de tous les utilisateurs");
        return repo.findAll();
    }
    
    public Optional<Utilisateur> findById(Long id) {
        logger.info("Recherche de l'utilisateur avec l'id : {}", id);
        return repo.findById(id);
    }
    
    public Utilisateur save(Utilisateur u) {
        logger.info("Enregistrement de l'utilisateur : {} {}", u.getPrenom(), u.getNom());
        return repo.save(u);
    }
    
    public void delete(Long id) {
        logger.info("Suppression de l'utilisateur avec l'id : {}", id);
        repo.deleteById(id);
    }
    
    public Optional<Utilisateur> findByEmail(String email) {
        logger.info("Recherche de l'utilisateur avec l'email : {}", email);
        return repo.findByEmail(email);
    }
}