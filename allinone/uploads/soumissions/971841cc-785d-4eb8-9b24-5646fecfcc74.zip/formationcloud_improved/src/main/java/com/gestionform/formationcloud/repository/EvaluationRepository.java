package com.gestionform.formationcloud.repository;

import com.gestionform.formationcloud.model.Evaluation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EvaluationRepository extends JpaRepository<Evaluation, Long> {
}
