package com.gestionform.formationcloud.repository;

import com.gestionform.formationcloud.model.SessionFormation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SessionFormationRepository extends JpaRepository<SessionFormation, Long> {
}
