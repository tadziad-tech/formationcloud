package com.gestionform.formationcloud.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "participation")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Participation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "stagiaire_id")
    private Utilisateur stagiaire;

    @ManyToOne
    @JoinColumn(name = "session_id")
    private SessionFormation session;

    private boolean presence = false;
    private Double note;
    private boolean certificat = false;
}