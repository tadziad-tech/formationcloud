package com.gestionform.formationcloud.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("cloud")
public class DatabaseConfig {
    // Configuration spécifique au cloud si nécessaire
}