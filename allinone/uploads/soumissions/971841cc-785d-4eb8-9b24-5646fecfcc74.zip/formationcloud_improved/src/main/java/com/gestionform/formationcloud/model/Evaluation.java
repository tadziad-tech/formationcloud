package com.gestionform.formationcloud.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "evaluation")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Evaluation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String commentaire;

    @Min(value = 0, message = "La note doit être comprise entre 0 et 20")
    @Max(value = 20, message = "La note doit être comprise entre 0 et 20")
    private Double note;

    @NotNull(message = "La date d'évaluation est obligatoire")
    private LocalDate dateEval;

    @ManyToOne
    @JoinColumn(name = "stagiaire_id")
    private Utilisateur stagiaire;

    @ManyToOne
    @JoinColumn(name = "formation_id")
    private Formation formation;
}