package com.gestionform.formationcloud.repository;

import com.gestionform.formationcloud.model.Participation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParticipationRepository extends JpaRepository<Participation, Long> {
}
