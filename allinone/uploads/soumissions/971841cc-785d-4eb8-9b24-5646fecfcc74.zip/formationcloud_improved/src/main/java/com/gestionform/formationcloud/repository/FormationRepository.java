package com.gestionform.formationcloud.repository;

import com.gestionform.formationcloud.model.Formation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FormationRepository extends JpaRepository<Formation, Long> {
}
