package com.gestionform.formationcloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormationCloudApplication {
    public static void main(String[] args) {
        SpringApplication.run(FormationCloudApplication.class, args);
    }
}
