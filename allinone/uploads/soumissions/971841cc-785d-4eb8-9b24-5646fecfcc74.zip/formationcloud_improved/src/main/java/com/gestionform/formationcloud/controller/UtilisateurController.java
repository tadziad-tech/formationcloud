package com.gestionform.formationcloud.controller;

import com.gestionform.formationcloud.exception.ResourceNotFoundException;
import com.gestionform.formationcloud.model.Utilisateur;
import com.gestionform.formationcloud.service.UtilisateurService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/utilisateurs")
@CrossOrigin(origins = "*")
public class UtilisateurController {
    
    private static final Logger logger = LoggerFactory.getLogger(UtilisateurController.class);
    
    private final UtilisateurService service;
    
    public UtilisateurController(UtilisateurService service) {
        this.service = service;
    }
    
    @GetMapping
    public List<Utilisateur> all() {
        logger.info("Récupération de tous les utilisateurs");
        return service.findAll();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Utilisateur> get(@PathVariable Long id) {
        logger.info("Récupération de l'utilisateur avec l'id : {}", id);
        Utilisateur utilisateur = service.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Utilisateur non trouvé avec l'id : " + id));
        return ResponseEntity.ok(utilisateur);
    }
    
    @PostMapping
    public Utilisateur create(@Valid @RequestBody Utilisateur utilisateur) {
        logger.info("Création d'un nouvel utilisateur : {} {}", utilisateur.getPrenom(), utilisateur.getNom());
        return service.save(utilisateur);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Utilisateur> update(@PathVariable Long id, @Valid @RequestBody Utilisateur userDetails) {
        logger.info("Mise à jour de l'utilisateur avec l'id : {}", id);
        Utilisateur utilisateur = service.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Utilisateur non trouvé avec l'id : " + id));
        
        utilisateur.setNom(userDetails.getNom());
        utilisateur.setPrenom(userDetails.getPrenom());
        utilisateur.setEmail(userDetails.getEmail());
        utilisateur.setMotDePasse(userDetails.getMotDePasse());
        utilisateur.setRole(userDetails.getRole());
        
        Utilisateur updatedUtilisateur = service.save(utilisateur);
        return ResponseEntity.ok(updatedUtilisateur);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        logger.info("Suppression de l'utilisateur avec l'id : {}", id);
        Utilisateur utilisateur = service.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Utilisateur non trouvé avec l'id : " + id));
        service.delete(id);
        return ResponseEntity.ok().build();
    }
    
    @GetMapping("/email/{email}")
    public ResponseEntity<Utilisateur> getByEmail(@PathVariable String email) {
        logger.info("Recherche de l'utilisateur avec l'email : {}", email);
        Utilisateur utilisateur = service.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Utilisateur non trouvé avec l'email : " + email));
        return ResponseEntity.ok(utilisateur);
    }
}