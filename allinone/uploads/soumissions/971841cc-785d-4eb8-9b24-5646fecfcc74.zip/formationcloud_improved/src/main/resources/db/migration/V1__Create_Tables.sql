CREATE TABLE utilisateur (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    role VARCHAR(50)
);

CREATE TABLE formation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(255) NOT NULL,
    description TEXT,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    lieu VARCHAR(255) NOT NULL,
    formateur_id BIGINT,
    FOREIGN KEY (formateur_id) REFERENCES utilisateur(id)
);

CREATE TABLE session_formation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    salle VARCHAR(255),
    formation_id BIGINT,
    FOREIGN KEY (formation_id) REFERENCES formation(id)
);

CREATE TABLE tache (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(255) NOT NULL,
    description TEXT,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    note DOUBLE,
    stagiaire_id BIGINT,
    formation_id BIGINT,
    FOREIGN KEY (stagiaire_id) REFERENCES utilisateur(id),
    FOREIGN KEY (formation_id) REFERENCES formation(id)
);

CREATE TABLE evaluation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    commentaire TEXT,
    note DOUBLE,
    date_eval DATE NOT NULL,
    stagiaire_id BIGINT,
    formation_id BIGINT,
    FOREIGN KEY (stagiaire_id) REFERENCES utilisateur(id),
    FOREIGN KEY (formation_id) REFERENCES formation(id)
);

CREATE TABLE participation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    presence BOOLEAN DEFAULT FALSE,
    note DOUBLE,
    certificat BOOLEAN DEFAULT FALSE,
    stagiaire_id BIGINT,
    session_id BIGINT,
    FOREIGN KEY (stagiaire_id) REFERENCES utilisateur(id),
    FOREIGN KEY (session_id) REFERENCES session_formation(id)
);

CREATE TABLE session_participants (
    session_id BIGINT NOT NULL,
    stagiaire_id BIGINT NOT NULL,
    PRIMARY KEY (session_id, stagiaire_id),
    FOREIGN KEY (session_id) REFERENCES session_formation(id),
    FOREIGN KEY (stagiaire_id) REFERENCES utilisateur(id)
);