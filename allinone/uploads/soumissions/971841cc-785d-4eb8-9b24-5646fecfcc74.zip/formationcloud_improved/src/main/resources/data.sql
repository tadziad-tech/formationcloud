INSERT INTO utilisateur (nom, prenom, email, mot_de_passe, role) VALUES
('El Amrani','Youssef','admin@pfemaroc.com','root','ADMIN'),
('Bennani','Sara','sara.bennani@ofppt.ma','root','FORMATEUR'),
('Tazi','Hicham','hicham.tazi@gmail.com','root','STAGIAIRE');

INSERT INTO formation (titre, description, date_debut, date_fin, lieu, formateur_id) VALUES
('Développement Spring Boot','Formation pratique Spring Boot','2025-05-01','2025-06-01','Casablanca',2);

INSERT INTO session_formation (date_debut, date_fin, salle, formation_id) VALUES
('2025-05-05','2025-05-09','Salle 12',1);
