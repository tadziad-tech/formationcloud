INSERT INTO utilisateur (nom, prenom, email, mot_de_passe, role) VALUES
('Dupont', 'Jean', 'jean.dupont@formationcloud.com', 'password123', 'FORMATEUR'),
('Martin', 'Marie', 'marie.martin@formationcloud.com', 'password456', 'STAGIAIRE'),
('Bernard', 'Pierre', 'pierre.bernard@formationcloud.com', 'password789', 'ADMIN');

INSERT INTO formation (titre, description, date_debut, date_fin, lieu, formateur_id) VALUES
('Java Spring Boot', 'Formation complète sur Spring Boot', '2023-01-15', '2023-01-20', 'Salle A', 1),
('Python Data Science', 'Analyse de données avec Python', '2023-02-10', '2023-02-15', 'Salle B', 1);

INSERT INTO session_formation (date_debut, date_fin, salle, formation_id) VALUES
('2023-01-15', '2023-01-20', 'Salle A1', 1),
('2023-02-10', '2023-02-15', 'Salle B1', 2);

INSERT INTO session_participants (session_id, stagiaire_id) VALUES
(1, 2),
(2, 2);

INSERT INTO tache (titre, description, date_debut, date_fin, note, stagiaire_id, formation_id) VALUES
('TP Spring Boot', 'Créer une application REST avec Spring Boot', '2023-01-15', '2023-01-18', 18.5, 2, 1);

INSERT INTO evaluation (commentaire, note, date_eval, stagiaire_id, formation_id) VALUES
('Très bonne compréhension des concepts', 19.0, '2023-01-20', 2, 1);